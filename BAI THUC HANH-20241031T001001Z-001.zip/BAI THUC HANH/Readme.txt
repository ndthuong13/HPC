1. Tải về và giải nén toàn bộ thư mục, đặt trong ổ đĩa D.
2. Tạo một Pycharm project trong chính thư mục đó (DATA ANALYSTIC)
3. Mở project và cài đặt các gói cần thiết.
4. Welcome.